For HTC Vive/Oculus Rift

list pics directories in filepaths.txt


controls
-----------------

menu - cycle directory

trackpad - toggle fap/edit mode

trigger - move/scale

grip - remove pic from scene


---

files removed from the scene in VR go to ./temp.fapurpics2