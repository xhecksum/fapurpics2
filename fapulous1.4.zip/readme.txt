VR pics viewer For HTC Vive/Oculus Rift


list pics directories in filepaths.txt
> c:\images
> c:\pics
etc.

supports .jpg, .png, .wav (audio)

controls
-----------------

menu - next directory

trackpad - toggle edit mode

trigger - move/scale

grip - delete pic from scene

trigger+trackpad l/r - change sound 

---
Changelog:

v1.4 - wav audio files will be picked up from any directory in the file list.
hold trigger and L/R on trackpad to cycle through audio files

v1.3 - deleted pics go to ./temp.fapurpics2